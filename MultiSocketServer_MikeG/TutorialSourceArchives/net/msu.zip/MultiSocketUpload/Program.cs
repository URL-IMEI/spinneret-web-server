﻿using System;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Linq;
using System.Collections.Generic;
using System.Configuration;

public class GetSocket
{

    // Fancypants socket routine
    private static Socket ConnectSocket(string server, int port)
    {
        Socket s = null;
        IPHostEntry hostEntry = null;

        IPAddress ip;
        if (IPAddress.TryParse(server, out ip))
            hostEntry = Dns.GetHostEntry(ip);
        else
            // Get host related information.
            hostEntry = Dns.GetHostEntry(server);

        foreach (IPAddress address in hostEntry.AddressList)
        {
            IPEndPoint ipe = new IPEndPoint(address, port);
            Socket tempSocket =  new Socket(ipe.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            tempSocket.Connect(ipe);

            if (tempSocket.Connected)
            {
                s = tempSocket;
                break;
            }
            else
            {
                continue;
            }
        }
        return s;
    }

    private static string SocketSendReceive(string server, int port)
    {
        //Header
        //The Spinneret dispatch method will execute the correct method
        //Firmware in this case.  The extension could be anything -> ah restFULL
        string request = "PUT /putbin HTTP/1.1\r\n";

        // Get the party started
        Byte[] bytesSent = Encoding.ASCII.GetBytes(request);
        Byte[] bytesReceived = new Byte[256];
        string responseText = string.Empty;

        // Fancypants socket guy.
        Socket socket = ConnectSocket(server, port);

        if (socket == null){
            return ("Connection failed");
        }

        // Send initial request to the server.
        socket.Send(bytesSent, bytesSent.Length, 0);
        responseText = GetResponseText(socket);
        Console.WriteLine(responseText);


        // Authenticate
        if (!Authenticate(socket))
            return @"Login failed!";

        int fileCounter = 0;
        int dirCounter = 0;
        string filename = string.Empty;
        string path = string.Empty;

        // Get source root directory and enumerate the folder within
        string rootDirectory = ConfigurationManager.AppSettings["localSiteRoot"];
        List<string> dirs =  EnumerateDirectories(rootDirectory);
        List<string> uploadFiles;

        foreach (string dir in dirs)
        {
            Console.WriteLine("\r\n---- Directory loop -----\r\n");
            Console.WriteLine("Directory Counter: {0}", dirCounter++);
            fileCounter = 0;

            if (dir == "\\")
            {
                uploadFiles = EnumerateFiles(rootDirectory);
                Console.WriteLine("Working Directory: {0}", rootDirectory);
            }
            else
            {
                uploadFiles = EnumerateFiles(string.Format("{0}\\{1}", rootDirectory, dir));
                Console.WriteLine("Working Directory: {0}\\{1}", rootDirectory, dir);
            }

            Console.WriteLine("Upload file count: {0}", uploadFiles.Count);

            ChangeDirectory(dir.ToUpper(), socket);

            foreach (string s in uploadFiles)
            {
                Console.WriteLine("\r\n---- File loop -----\r\n");
                Console.WriteLine("File Counter: {0}", ++fileCounter);
                path = s.ToUpper();
                filename = Path.GetFileName(path);

                if (filename == "ROBOTS.TXT" || filename == "ROOT.HTM") //|| filename == "THUMBS.DB"
                {
                    Console.WriteLine("Skipped {0} File Counter: {1}", filename, fileCounter);
                    continue;
                }
                    

                Console.WriteLine("File to upload {0}", filename);

                // Send the file name to the server and wait for the response
                bytesSent = Encoding.ASCII.GetBytes(filename);
                socket.Send(bytesSent, bytesSent.Length, 0);
                responseText = GetResponseText(socket);
                Console.WriteLine(responseText);


                // Use a binary reader to parse the file to uplaod
                BinaryReader binReader = new BinaryReader(File.Open(path, FileMode.Open));
                long bytesToRead = binReader.BaseStream.Length;
                binReader.BaseStream.Position = 0;

                // Get the byte count.
                // Max byte count transmitted at one time is 1460
                byte[] data;
                int count = bytesToRead >= 1460 ? 1460 : (int)bytesToRead;
                int idx = 0;

                // Send the byte count to the server and wait for the response
                bytesSent = Encoding.ASCII.GetBytes(bytesToRead.ToString());
                socket.Send(bytesSent, bytesSent.Length, 0);
                responseText = GetResponseText(socket);
                Console.WriteLine(responseText);


                try
                {   // Loop through the file 1460 bytes at a time (or whatever is left)
                    do
                    {
                        data = new byte[count];
                        idx += count;

                        // Read and send
                        binReader.Read(data, 0, count);
                        socket.Send(data, data.Length, 0);

                        // Get the response
                        responseText = GetResponseText(socket);
                        Console.WriteLine(responseText);
                        Console.WriteLine("Bytes sent: {0}", idx);

                        if(responseText == "TIMEOUT")
                            return string.Format("Timeout writing {0}", filename);

                        // Give the Spinneret a breath
                        Thread.Sleep(100);

                        // Are we at the end?
                        if (count > bytesToRead - idx)
                            count = Convert.ToInt32(bytesToRead - idx);

                    }
                    while (idx < bytesToRead);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    binReader.Close();
                }

                Console.WriteLine("uploadFiles.Count = {0} | fileCounter = {1}", uploadFiles.Count, fileCounter);


                if (fileCounter < uploadFiles.Count && uploadFiles.Count > 0)
                    SendFileCommand(@"PUT", socket);

                Thread.Sleep(100);

            }// File loop


            Boolean singleFile = Boolean.Parse(ConfigurationManager.AppSettings["singleFile"]);
            if(singleFile)
            {
                SendFileCommand(@"QUIT", socket);
                return "Done!";
            }

            if (fileCounter == uploadFiles.Count && dir == "\\")
            {
                SendFileCommand(@"QUIT", socket);
                return "Done!";
            }

            SendFileCommand(@"CD", socket);
        }// directory loop

        return "We did not exit gracefully!";
    }


    // Authenticate
    public static bool Authenticate(Socket socket)
    {
        string responseText;
        byte[] bytesSent;

        Console.Write("Enter your ID: ");
        string username = Console.ReadLine();

        // Lazy Default
        if(string.IsNullOrEmpty(username))
             username = ConfigurationManager.AppSettings["username"];

        // Encode and send
        bytesSent = Encoding.ASCII.GetBytes(username);
        socket.Send(bytesSent, bytesSent.Length, 0);

        // Get the response
        responseText = GetResponseText(socket);
        Console.WriteLine(responseText);

        if (responseText.Contains("No Dice"))
            return false;

        return true;
    }


    public static string SendFileCommand(string command, Socket socket)
    {
        string responseText;
        byte[] bytesSent;

        bytesSent = Encoding.ASCII.GetBytes(command);

        socket.Send(bytesSent, bytesSent.Length, 0);
        responseText = GetResponseText(socket);
        Console.WriteLine(responseText);

        return responseText;

    }

    public static string ChangeDirectory(string directory, Socket socket)
    {
        string responseText;
        byte[] bytesSent;

        if (directory == "\\")
            directory = @"\";

        bytesSent = Encoding.ASCII.GetBytes(directory);

        socket.Send(bytesSent, bytesSent.Length, 0);
        responseText = GetResponseText(socket);
        Console.WriteLine(responseText);

        return responseText;
    }


    // Response helper
    public static string GetResponseText(Socket s)
    {
        int bytes = 0;
        string current = string.Empty;
        byte[] bytesReceived = new Byte[256];
        do
        {
            bytes = s.Receive(bytesReceived, bytesReceived.Length, 0);
            current = Encoding.ASCII.GetString(bytesReceived, 0, bytes);
        }
        while (current.Length == 0);

        return current;
    }



    private static List<string> EnumerateDirectories(string path)
    {
        List<string> dirList = new List<string>();

        try{
            // LINQ query.
            var dirs = from dir in 
                       Directory.EnumerateDirectories(path)
                       select dir;

            Console.WriteLine();
            // Show results.
            foreach (var dir in dirs)
            {
                var files = from file in Directory.EnumerateFiles(dir) select file;

                if (files.Count<string>() > 0)
                {
                    // Remove path information from string.
                    Console.WriteLine("{0}", dir.Substring(dir.LastIndexOf("\\") + 1));
                    dirList.Add(dir.Substring(dir.LastIndexOf("\\") + 1));
                }
            }

            Console.WriteLine("{0} directories found.", dirs.Count<string>().ToString());
            Console.WriteLine();

            dirList.Add(@"\");
            return dirList;
        }
        catch (UnauthorizedAccessException UAEx)
        {
            Console.WriteLine(UAEx.Message);
            return null;
        }
        catch (PathTooLongException PathEx)
        {
            Console.WriteLine(PathEx.Message);
            return null;
        } 
    }

    private static List<string> EnumerateFiles(string dir)
    {
        try
        {
            var files = from file in
                        Directory.EnumerateFiles(dir)
                        select file;

            Console.WriteLine();
            // Show results.
            foreach (var file in files)
            {
                Console.WriteLine("{0}", file);
            }
            Console.WriteLine("{0} files found.", files.Count<string>().ToString());
            Console.WriteLine();
            // Return a list collection.
            List<string> uploadFiles = new List<string>(files);
            return uploadFiles;
        }
        catch (UnauthorizedAccessException UAEx)
        {
            Console.WriteLine(UAEx.Message);
            return null;
        }
        catch (PathTooLongException PathEx)
        {
            Console.WriteLine(PathEx.Message);
            return null;
        }  
    }



    // Main entry
    public static void Main(string[] args)
    {

        string host = ConfigurationManager.AppSettings["remoteSite"];
        int port = 5000;
        if (!int.TryParse(ConfigurationManager.AppSettings["port"], out port))
            Console.WriteLine("Error parsing the port appsetting in the configuration file.");

        string result = SocketSendReceive(host, port);
        Console.WriteLine("\r\n{0}\r\n", result);
    }
}

